This code contains the following files, which were run on Matlab 2016.  They are what I used to generate the data for the figures in our paper.  Additionally, there is a folder called "code_and_data_for_figs", which is full of .m files for making the figures, and all of the actual simulation runs.

dies_out_func2.m -> This code takes in data for a community and determines equilibrium abundance, and stochastic and deterministic stability.  It does this by running JC_differnt_alphas.m many times, and is used by spread_can_invade_long.m and spread_same_ri_HPC.m.
draw_BCI5.m -> This program analyzes data from Comita et al and generates figure 5 (arrows need to be added later).
JC_different_alphas.m -> This is the main code for simulating the community dynamics.  It is used my most other programs.
liza_data.m -> This is the date from Comita et al. (2010) which we use in the figure.  (species names are listed in combined_data.xlsx)
mycov.m -> This is a simple program I wrote because I got sick of dealing with Matlab's cov function.
one_invasion.m -> This uses JC_different_alphas.m to run an invasion analysis on all species, and outputs each species' invader growth rate.
spread_can_invade_long.m -> This determines deterministic stability in many communities as susceptibility to CNDD varies.
spread_same_ri_HPC.m -> This analyzes stochastic and deterministic stability in many communities, both as susceptibility to CNDD and yield vary. 
temp_analyze_cov_approx.m -> This analyzes the data from temp_test_cov_approx.m to make sure that my approximations are decent.
temp_n_and_r.m -> This runs JC_different_alphas.m many times to determine the link between abundance and growth rate.
temp_test_cov_approx.m -> This generates 200 random communities and determines the abundance and invader growth rate in each.