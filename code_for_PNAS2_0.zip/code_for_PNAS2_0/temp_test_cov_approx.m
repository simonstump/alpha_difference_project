%This file makes the data for Figures S4.  You will need to run 
%temp_analyze_cov_approx.m to create the figure. It creates a data file 
%called called data_for_cov_approx.mat, and in the middle of the 
%simulation, one called data_for_cov_approx_temp.mat.  If you need to stop
%the simulation and start it again, you will need the _temp file.

clc, clear, close all
RUNS=200;

GEN= [100000, .002, .005, .001, 0 6000, 2000, 0];
%GEN= [50000, .002, .005, .001, 0 2000, 1000, 0];  %for testing

%should give a growth rate error that is about 4*10^-4, plus the 
%above-replacement births divided by 1000.

REP=1;   %leave this as 1

maxS=11;   %maximum number of species

saveN=zeros(maxS,RUNS);   %saves the density of species in the full-species run.
saveNi=zeros(maxS,maxS,RUNS);  %saves the density of species in each invasion analysis.
saveA=zeros(maxS,RUNS);   %saves the \alpha value of each species.
saveSPP=zeros(RUNS,1);   %saves the # of species in each community.
saveRi=zeros(maxS,RUNS);   %saves the invader growth rate of each species.
saveNi2=zeros(maxS,maxS,RUNS);  %like saveNi, but for a replicate run.
saveRi2=zeros(maxS,RUNS);   %line saveRi, but for a replicate run.
saveRiguess=zeros(maxS,RUNS);   %saves the estimate invader growth rate.

%if you turn the code off and need to restart it, change the if to if(1).
if(0)
    clc, clear
    RUNS=200;
    load('data_for_cov_approx_temp')
    runstart=i;
end

for i=runstart:RUNS
    
    GEN(8)=0;   %makes sure there is no invader during the first run.

    %here I set the parameters for a given run
    SPP=2+randi(maxS-2)   %number of species in initial run
    d=.65+.35*rand()  %dispersal rate
    
    Ydif=.2*rand()   %the amount Yield varies between species
    Adif=.5*rand()   %the amount alpha differs between species
    Abar=.05+rand()*.5   %the mean value of alpha
    
    
    SPP_MAT=repmat([1 .4 d 1],SPP,1);
    SPP_MAT(:,1)=1+rand(SPP,1)*Ydif;   %the yield for each species
    SPP_MAT(:,4)=min(1,Abar*(1-Adif/2+rand(SPP,1)*Adif))  %the alpha for each species
    
    COV_MAT=eye(SPP)*10^-20;  %do not change this.
    
    
    'run'
    i
    
    nbarX=zeros(REP,SPP);
    %for j=1:REP
        %i

        %initial simulation run to see who survives.
        [x nbarX(1,:)]=JC_different_alphas(SPP_MAT, COV_MAT, GEN)
        
    %end
    
    nbarX%=nbarX
    
    %here I remove any species that don't survive the initial run.
    ii=1;
    while(ii<=SPP)
        if(nbarX(ii)<GEN(4))
            SPP_MAT(ii,:)=[];
            SPP=SPP-1;
            nbarX(ii)=[];
            ii;
        else
            ii=ii+1;
        end
    end
    
    SPP
    %SPP_MAT
    %pause

    %here I save data about the survivors
    saveSPP(i)=SPP;
    saveN(1:SPP,i)=nbarX/sum(nbarX);
    saveA(1:SPP,i)=SPP_MAT(:,4);
    saveY(1:SPP,i)=SPP_MAT(:,1);
    

    %here I do an invasion analysis, if there are at least 2 species
    if(SPP>2)
        nInvade=zeros(SPP,SPP,REP);
        ri=zeros(SPP,REP);
        nInvade2=zeros(SPP,SPP,REP);
        ri2=zeros(SPP,REP);
        
        %for r=1:REP
            for j=1:SPP
                %i
                GEN(8)=j;
                
                [ri(j) nInvade(j,:,1)]=JC_different_alphas(SPP_MAT, COV_MAT, GEN);
                [ri2(j) nInvade2(j,:,1)]=JC_different_alphas(SPP_MAT, COV_MAT, GEN);
            end
        %end
        

        %here I save the data from the invasion analysis
        saveNi(1:SPP,1:SPP,i)=nInvade;
        saveRi(1:SPP,i)=ri;
        saveNi2(1:SPP,1:SPP,i)=nInvade2;
        saveRi2(1:SPP,i)=ri2;
        
        %here I calculate Delta P and Delta Y, to estimate the invader growth rates
        logY=log(SPP_MAT(:,1));
        meanY=mean(logY);
        alpha=SPP_MAT(:,4);
        meanA=mean(alpha);
        
        ri
        guess=(logY-meanY)*d*(2-d)*SPP/(SPP-1)+...
            (meanA-alpha)*(d*(1-d)*SPP/(SPP-1)+d^2/(SPP-1)^d)+...
            d^2*(meanA/(SPP-1)+mycov(alpha,nbarX))
        
        saveRiguess(1:SPP,i)=guess;
        saveStabguess(i)=mean(guess);
    end
    
    save('data_for_cov_approx_temp')
    
end

save('data_for_cov_approx')