function [r_i] = one_invasion(SPP_MAT, GEN2, COV_MAT)

%r_i = one_invasion(SPP_MAT, GEN, COV_MAT)
%
%This function runs an invasion analysis for one community, to determine deterministic stability.  It outputs this in as a vector of invader growth rates.
%
%The code takes the following inputs (which are described in JC_different_alphas):
%SPP_MAT is a matrix of species values, SPP_MAT
%GEN is a vector of values for the community.
%COV_MAT should be an n-by-n (n=#of species) of zeroes for this (legacy thing).


SPP=size(SPP_MAT,1);


r_i=zeros(SPP,1);
%parfor(j=1:REPS2)
for(i=1:SPP)   %I run through every species
    GEN2(8)=i;   %make species i the invader.
    r_i(i)=JC_different_alphas(SPP_MAT,COV_MAT,GEN2);
end

death=SPP_MAT(1,3);

r_i=(r_i-1)/death;  %this converts it from lambda to lambda' (i.e. a per-capita rate).



