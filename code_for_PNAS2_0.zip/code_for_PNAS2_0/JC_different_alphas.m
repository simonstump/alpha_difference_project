function [growth,nbar,record] = JC_different_alphas(SPP_MAT, COV_MAT, GEN, varargin)

%[growth,nbar,record] = JC_model(SPP_MAT, PRED_MAT, COV_MAT, GEN)
%
%This code runs my forest community model.  It was adapted from Stump & Chesson (2015, TPB), Stump (2017, American Naturalist), and Simon Stump's dissertation work.  As such, it still has some functions that were unused in the paper (such as habitat partitioning).  Basically, you will input data on the species and their niche relationships, and the code will output the invader growth rate ('growth') and final density of each %species ('n_out').  It can be run as in invasion analysis, or just as a normal population dynamics model.  The inputs are:
%
%SPP_MAT is an nx4 dimensional matrix (where n is the number of species). The first column is the Yield of each species (Y_j in the paper), and the third column is their death rate (\delta in the paper).  I only consider the 1st entry in the second and third column (i.e., each species has the same death rate and dispersal), it was set up as a column because I previously thought I'd want to have them vary.
%
%PRED_MAT in an nxn matrix, where entry i,j is predator niche overlap between species i and j (i.e., \alpha * rho_ij)$
%
%COV_MAT is somewhat of a legacy from previous studies.  It is an nxn covariance matrix, where entry i,j is the covariance in the effect of habitat (i.e., E_ij) between species i and j.  If you do not want to consider habitat partitioning, set it so that the highest values is 10^-7 or smaller (this will speed up the code).
%
%GEN is 1x8 a matrix of the following general parameters:
%GEN = [AREA, INVADE, INVADE_max, INVADE_min, PRETIME, TIME, RECORD_TIME, invader#]
%1-AREA: number of sites in the community
%2-INVADE: the fraction of community that will be the invader when it first invades.
%3-INVADE_max: the maximum fraction of the community that can be the invader.
%4-INVADE_min: the minimun fraction of the community that can be the invader.
%5-PRETIME: the amount of time the simulation runs before the invader is added.
%6-TIME: the amonut of time the simulation runs after the invader is added.
%7-RECORD_TIME: the amount of time you record to calculate the invader's growth rate.
%8-INVADER: The invader is this one (i.e., this is an integer between 1 and n); alternatively, if this is 0, then the simulation is run normally, rather than as an invasion analysis.
%
%varagin is optional.  If you exclude it, then all species will start at equal densities. If you include it, then you must input a vector of length n (number of spp), where each entry is that species's starting frequency.  Thus, the values must sum to 1.
%
%
%This function outputs 3 things:
%growth- This is the average finite rate of increase for the invader.  If you do not have an invader, then this is the same as near.
%nbar- This is the frequency of each species at the end of the simulation
%record- This is the frequency of each species throughout the simulation.

% %
% %for testing (uncomment the lines below, and comment out the 1st line, and
% %this will run as a subroutine instead of a function)
% SPP_MAT = [1, .7, .4 .2;...
%     1.1, .7, .4 .25;...
%     1, .7, .4 .25;...
%     1.1, .7, .4 .3;...
%     1, .7, .4 .3]
% thevar = 0;
% COV_MAT = thevar*[1  0  0  0  0;...
%     0  1  0  0  0;...
%     0  0  1  0  0;...
%     0  0  0  1  0;...
%     0  0  0  0  1]
% % %GEN = [AREA, INVADE, INVADE_max, INVADE_min, PRETIME, TIME,...
% % %      RECORD_TIME, invader#]
% GEN = [10, .002, .005, .001, 1000, 1000, 500, 0]
% varargin=[.2 .2 .2 .2 .2];


%%%%%%%%%%%%%%
%set up the various parameters
%%%%%%%%%%%%%%

AREA = GEN(1);   %This is the number of adults in the community
[SPP ~] = size(SPP_MAT);        %Total # of spp (must be more than 1).
INVADE = GEN(2);    %This is the frequency of invaders that are introduced.
INVADE_max = GEN(3); %This is the maximum freq. of invaders that there can be.
INVADE_min = GEN(4);  %This is the minimum freq. of invaders that there can be.
PRETIME = GEN(5);      %This is how many simulation steps before invaders are introduced.  Thus, TIME-PRETIME is how many steps the simulation can come to equilibrium.
TIME = GEN(6);         %Number of simulation steps post pre-time.
RECORD_TIME = GEN(7);  %Number of generations recorded for coexistence.
RECORD_HERE = max(1,TIME-RECORD_TIME); %The generation when recording starts.
THEMAX = ceil(AREA*INVADE_max);  %This is the max number of invaders.
THEMIN = ceil(AREA*INVADE_min);  %This is the min number of invaders.

INV_NUM = GEN(8); %the # of the invader spp
if(INV_NUM==0)
    PRETIME=0;
end


alpha=SPP_MAT(:,4); %strength of CNDD

yield = SPP_MAT(:,1);   %the number of seeds produced per adult
yield_mat=repmat(yield',AREA,1);

disp = SPP_MAT(1,2); 	%the seed dispersal rate
delta = SPP_MAT(1,3);   %the death rate



%location tells you which species is at which spatial location

nVarargs = length(varargin);
switch nVarargs
    case 0
        if(INV_NUM==0)
            location = randi(SPP,AREA,1);
        else
            %this step makes sure to remove teh invaders
            location = randi(SPP-1,AREA,1);
            location = location+(location>=INV_NUM);
        end
    case 1
        nbar=varargin{1};
        %nbarS=nbar;
        location=zeros(AREA,1);
        
        location(1:floor(AREA*nbar(1)))=1;
        %pause
        for(i=2:length(nbar)-1)
            %nbarS(i:SPP)=nbarS(i:SPP)+nbar(i-1)
            location(floor(AREA*sum(nbar(1:i-1)))+1:floor(AREA*sum(nbar(1:i))))=i;
        %    pause
        end
        location(floor(AREA*sum(nbar(1:SPP-1)))+1:AREA)=SPP;
        %pause
        %nbar
        %[mean(location==1) mean(location==2) mean(location==3) ...
        %    mean(location==4) mean(location==5)]
end

%record gives the frequency of each species throughout the simulation.
record = zeros(TIME+PRETIME,SPP);

%lambda records the finite rate of increase of the invader.
lambda = zeros(RECORD_TIME,1);


%seed_rain is used later, it gives the number of seeds of each species that fall at each location.
seed_rain=yield_mat;

%pred_mat is used later to determine the effect of CNDD at each location.  If all species have the same alpha_j, then I make it a constant to speed things up.
if(var(alpha)>10^-10)
    pred_mat=repmat(alpha',AREA,1);
    pred_mat(pred_mat>1)=1;
else
    pred_mat=alpha(1);
end


%This sets up the effect of habitat partitioning (not used in this paper)
meany = zeros(AREA,SPP);  

if(max(max(COV_MAT))>10^-7)
    E = ones(AREA,SPP);
    %Here is where I set up the E's (i.e., the effect of habitat).
    x1 = randn([AREA,SPP]);
    E = exp((x1*chol(COV_MAT))+meany);
    E = E/(mean(mean(E)));
else
    E=1;
end

forN=repmat([1:SPP],AREA,1);

%If it is an invasion analysis, I run the simulation for PRETIME with just
%the residents before introducing an invader.
N=(forN==repmat(location,1,SPP));
N_bar=mean(N);
if(INV_NUM>0)
    for t=1:PRETIME
        
        %first I calculate how many seeds of each species are dispersed to each site.
        for(j=1:SPP)
            seed_rain(:,j)=N_bar(j).*yield(j)*disp;
        end
        
        non_dispersed=(1-disp)*N.*yield_mat; %number of non-disprsed seeds
        
        all_seeds=(seed_rain+non_dispersed).*E.*(1-N.*pred_mat); %total number of seeds, weighted by E
        
        C=all_seeds*ones(SPP,1);  %effect of competition
        
       
        
        %My algorithm is approximately as follows.  First, I calculate the
        %probability of taking a site for each species in prob (above).  For
        %example, for 3 species, these probabilities might be A, B, and C
        %(where A+B+C=1).  I generate a U(0,1) random number called this_rand,
        %and set the cite to (SPP+1) (in my example, 4).  If this_rand<A, I
        %subtract 1 from (SPP+1) (in my example, giving me 3).  I then do this
        %for A+B, then A+B+C, and so on.  This is the equivalent to saying, "If
        %this_rand is less than A, spp. 1 takes the cite.  If this_rand is less
        %than A+B, spp. 2 takes it, and so on.
        this_rand = rand(AREA,1).*C;
        
        here2 = SPP+1-(this_rand<all_seeds(:,1));
        
        for i=2:SPP
            all_seeds(:,i) = all_seeds(:,i) + all_seeds(:,i-1);
            here2 = here2-(this_rand<all_seeds(:,i));
        end

        
        lives = (rand([AREA 1])>delta);     %this sees which ones die
        location=here2.*(1-lives) + location.*lives;  %whatever number is left, that is who is there.
        N=(forN==repmat(location,1,SPP));
        N_bar=mean(N);
        
        record(t,:) = N_bar;
        %pause
        
        % N_bar=mean(N)
        %
        % record(t-1,i) = N_bar;
        
        
        
    end
    
    %If you are here, it means the code has run for PRETIME time steps without the invader.

    %plot(record)
    %return
    
    %now I drop a whole bunch of invaders in random spots.
    invader_here = unique(randi(AREA,ceil(INVADE*AREA),1));
    
    location(invader_here) = INV_NUM;
end


for t=1:TIME
    %%%%%%%%%%%%%For the next several lines, this is copied from above.
    
    
    for(j=1:SPP)
        seed_rain(:,j)=N_bar(j).*yield(j)*disp;
    end
    
    %seed_rain
    
    non_dispersed=(1-disp)*N.*yield_mat; %number of non-disprsed seeds
    
    all_seeds=(seed_rain+non_dispersed).*E.*(1-N.*pred_mat); %total number of seeds, weighted by E
    
    C=all_seeds*ones(SPP,1);  %effect of compettiion
    
    %pause
    
    
    %My algorithm is approximately as follows.  First, I calculate the
    %probability of taking a site for each species in prob (above).  For
    %example, for 3 species, these probabilities might be A, B, and C
    %(where A+B+C=1).  I generate a U(0,1) random number called this_rand,
    %and set the cite to (SPP+1) (in my example, 4).  If this_rand<A, I
    %subtract 1 from (SPP+1) (in my example, giving me 3).  I then do this
    %for A+B, then A+B+C, and so on.  This is the equivalent to saying, "If
    %this_rand is less than A, spp. 1 takes the cite.  If this_rand is less
    %than A+B, spp. 2 takes it, and so on.
    this_rand = rand(AREA,1).*C;
    
    here2 = SPP+1-(this_rand<all_seeds(:,1));
    
    for i=2:SPP
        all_seeds(:,i) = all_seeds(:,i) + all_seeds(:,i-1);
        here2 = here2-(this_rand<all_seeds(:,i));
    end
    %here2';
    %pause
    
    lives = (rand([AREA 1])>delta);     %this sees which ones die
    location=here2.*(1-lives) + location.*lives;  %whatever number is left, that is who is there.

    
    
    %%%%%%%%%New stuff
    
    %here I calculate the invader growth rate and adjust its densities
    if(INV_NUM~=0)
        N_i = mean(location==INV_NUM);  % percent of invaders on the landscape.
        
        if(t>RECORD_HERE)
            %This records the degree to which the invader population has grown
            %or shrunk (this is done before the population is rescaled back to
            %the invader limits).
            lambda(t-RECORD_HERE) = N_i/N_bar(INV_NUM);
            
            %If the invader died off, I set lambda to -42, and delete it
            %later.
            if(N_i == 0)
                lambda(t-RECORD_HERE) = -42;
            end
        end
        
        
        Nipop = N_i*AREA;  %actual # of invaders.
        if(N_i > INVADE_max)
            %If there are too many invaders, kill a few at random.
            
            %Here_i is a list of where the invader is located.  Points from it
            %are drawn randomly, and those trees are killed.
            here_i = (location==INV_NUM).*[1:AREA]';
            here_i(here_i==0) = [];
            
            for i = THEMAX:(N_i*AREA-1)
                killit = randi(length(here_i),1);
                replaceit = randi(AREA,1);
                while(location(replaceit) == INV_NUM)
                    %This while loop stops me from replacing a dead invader
                    %with another invader.
                    replaceit = randi(AREA,1);
                end
                location(here_i(killit)) = location(replaceit);
                here_i(killit) = [];
            end
            %N_i = mean(location==INV_NUM);
        elseif(THEMIN > Nipop)
            %If there are not enough invaders, put them back in in random
            %locations.
            location(randi(AREA,[ceil(THEMIN-Nipop) 1])) = INV_NUM;
            
        end
        
    end
    
    N=(forN==repmat(location,1,SPP));
    N_bar=mean(N);
    
    record(t+PRETIME,:) = N_bar;
    
    
    
end

%plot(record)
nbar=mean(record(RECORD_HERE:TIME,:));


%%%Uncomment this if you'd like to see a plot of the population dynamics.
%plot([1:TIME+PRETIME],record, [1 TIME+PRETIME], AREA*[INVADE_max INVADE_max],...
%    'k--', [1 TIME+PRETIME], AREA*[INVADE_min INVADE_min], 'k--')
%
%legend('spp 1','spp 2','spp 3','spp 4','spp 5')

if(INV_NUM>0)  %If there is an invader, output its invasion rate.
    lambda(lambda==-42) = [];
    
    n_out=mean(record(RECORD_HERE:TIME,:))/...
        (AREA-mean(record(RECORD_HERE:TIME,INV_NUM)));
    
    growth = mean(lambda);
else  %If no invader, output everyone's density.
    %plot(record)
    
    n_out = mean(record(RECORD_HERE:TIME,:))/AREA;
    
        
    for j = 1:SPP
        growth(j)=mean(location==j);
    end
    %growth
end
