function [firstLoss numSpp r_i nbarO] = dies_out_func2(SPP_MAT, GEN, GEN2, GEN3, COV_MAT, nbar, REPS, REPS2, REPS3)

%[firstLoss numSpp r_i nbarO] = dies_out_func2(SPP_MAT, GEN, GEN2, GEN3, COV_MAT, nbar, REPS, REPS2, REPS3)
%
%This program takes in a community and determines its deterministic and stochastic stability.  It outputs this in 4 ways:
%firstloss- This gives stochastic stability.  It is a vector of length REPS, which tells how many time steps a small community ran before a species went extinct.  
%numSpp- This is also stochastic stability, and uses the same simulations used to run firstloss.  It is a vector of length REPS, where each number is the number of species who survived to the end of a simulation.
%r_i- This is deterministic stability.  It gives the invader growth rate of each species.  It is the nomalized value (i.e., (lambda-1)/delta, described in the appendix).
%nbar0- This is the frequency of each species at the end of the simulation.
%
%The code takes the following inputs (which are described in JC_different_alphas):
%SPP_MAT is a matrix of species values, SPP_MAT
%GEN is a vector of values for the community (called GEN elsewhere), which is for the stochastic stability trial.
%GEN2 is GEN but for the deterministic stability trial.
%GEN3 is GEN but for calculating frequencies.
%COV_MAT should be an n-by-n (n=#of species) of zeroes for this (legacy thing).
%nbar is the frequency we start the community at in the demographic stochasticity trials
%REPS is the number of simulations used for stochastic stability.
%REPS2 is the number of simulations used for deterministic stability.
%REPS3 is the number of simulations used for density.



%%%%%%%%%%%%%%%
%stochastic stability

firstLoss=zeros(REPS,1);
numSpp=firstLoss;

SPP=size(SPP_MAT,1);  %number of species

%if nbar=-1, then I start every species at a random frequency according to a broken stick distribution.  I ended up not using this for the paper.
%otherwise, I stat every species at frequency determined by nbar
if(nbar==-1)
    for i=1:REPS
        forN=sort(rand(SPP-1,1))*(1-.05*SPP);
        nbarX(1)=.05+forN(1);
        for(ii=2:SPP-1)
            nbarX(ii)=.05+forN(ii)-forN(ii-1);
        end
        nbarX(SPP)=1-sum(nbarX(1:SPP-1));
        
        %pause
        
        [x y record]=JC_different_alphas(SPP_MAT, COV_MAT, GEN, nbarX);
        firstLoss(i)=sum(sum(record'>0)==SPP);
        numSpp(i)=mean(record(length(record),:)>0);
    end
else
    
    %here I simulate the community REPS times and record when the first species is lost, and how many species survive.

    for i=1:REPS
        [x y record]=JC_different_alphas(SPP_MAT, COV_MAT, GEN, nbar);
        firstLoss(i)=sum(sum(record'>0)==SPP);
        numSpp(i)=mean(record(length(record),:)>0);
    end
end


%%%%%%%%%%%%%%%
%deterministic stability

r_i=zeros(SPP,REPS2);
for(j=1:REPS2)    %for each repeated simulation
for(i=1:SPP)    %for each species
    GEN2(8)=i;  %I set species i to be the invader
    %[i j]
    r_i(i,j)=JC_different_alphas(SPP_MAT,COV_MAT,GEN2);
end
end

%JC_different_alphas outputs invader growth rates as tilde{lambda}, below I normalize it (what I call \tilde{\lambda}' in the paper)

death=SPP_MAT(1,3);

r_i=(r_i-1)/death;

%%%%%%%%%%%%%%%
%calculate equilibrium density

nbarX=zeros(REPS3,SPP);
for i=1:REPS3
    %i
    [x nbarX(i,:)]=JC_different_alphas(SPP_MAT, COV_MAT, GEN3);
    
end

nbarO=mean(nbarX);

