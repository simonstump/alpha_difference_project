function out = mycov(x,y)

mat=cov(x,y,1);
out=mat(1,2);