%This file Figure 2.  It uses '20171113_alphaSpread4_1', '20171113_alphaSpread4_5', '20171113_alphaSpread4_6', and '20171113_alphaSpread4_1'

close all
clear


load('20171113_alphaSpread4_1')

r_i3=r_i;

r_i3x=r_i3;

damax=size(r_i3,2);
for i=1:damax-1
    if(min(r_i3x(:,i))<0)
        r_i3x(:,i:damax)=NaN;
    end
end

alpha3=alpha;

CNDD=reshape(SPP_MAT_ALL(:,4,:),SPP,20);
sig3=std(CNDD);
d3=disp;


load('20171113_alphaSpread4_5')

r_i2=r_i;

r_i2x=r_i2;
damax=size(r_i2x,2);
for i=1:damax-1
    if(min(r_i2x(:,i))<0)
        r_i2x(:,i:damax)=NaN;
    end
end

alpha2=alpha;
d2=disp;


CNDD=reshape(SPP_MAT_ALL(:,4,:),SPP,20);
sig2=std(CNDD);


load('20171113_alphaSpread4_6')

r_i2a=r_i;

r_i2ax=r_i2a;
damax=size(r_i2ax,2);
for i=1:damax-1
    if(min(r_i2ax(:,i))<0)
        r_i2ax(:,i:damax)=NaN;
    end
end

alpha2a=alpha;
d2a=disp;


CNDD=reshape(SPP_MAT_ALL(:,4,:),SPP,20);
sig2a=std(CNDD);


load('20171113_alphaSpread4_7')

r_i1=r_i;

r_i1x=r_i1;
damax=size(r_i1x,2);
for i=1:damax-1
    if(min(r_i1x(:,i))<0)
        r_i1x(:,i:damax)=NaN;
    end
end

alpha1=alpha;
d1=disp;

CNDD=reshape(SPP_MAT_ALL(:,4,:),SPP,20);
sig1=std(CNDD);


sig3

figA=figure();

plot(sig3,sum(r_i3>0),'ko-',...
    sig2,sum(r_i2>0),'ks-',...
    sig2a,sum(r_i2a>0),'k*-',...
    sig1,sum(r_i1>0),'k^-',...
    'LineWidth',2,'MarkerSize',8)

l=legend(['$d=$',num2str(d3)],...
    ['$d=$',num2str(d2)],...
    ['$d=$',num2str(d2a)],...
    ['$d=$',num2str(d1)]);
set(l,'Interpreter','latex','Location','NorthEast');


xlabel('Varitaion in CNDD, i.e., $\sigma_{\alpha_j}$','interpreter','latex');
ylabel('Number of persisting species','interpreter','latex');

title('(a) Variation in CNDD affects species richness','interpreter','latex');

set(gca,'fontsize', 12);

axis([0 max(sig3) 0 SPP+.25])

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig2_alive.pdf'])


%%%%%%%%


figA=figure();

plot(sig3,mean(r_i3x),'ko-',...
    sig2,mean(r_i2x),'ks-',...
    sig2a,mean(r_i2ax),'k*-',...
    sig1,mean(r_i1x),'k^-',...
    'LineWidth',2,'MarkerSize',8)


xlabel('Varitaion in CNDD, i.e., $\sigma_{\alpha_j}$','interpreter','latex');
ylabel('Stability (mean $\tilde{\lambda}_i$)','interpreter','latex');

title('(b) Variation in CNDD affects stailizing mechanisms','interpreter','latex');

set(gca,'fontsize', 12);

%axis([0 max(sig) -.002 .022])

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig2_stab.pdf'])


%%%%%%%%%%%%%%%%%%%%%%


figA=figure();

plot(sig3,r_i3x(SPP,:)-mean(r_i3x),'ko-',...
    sig2,r_i2x(SPP,:)-mean(r_i2x),'ks-',...
    sig2a,r_i2ax(SPP,:)-mean(r_i2ax),'k*-',...
    sig1,r_i1x(SPP,:)-mean(r_i1x),'k^-',...
    'LineWidth',2,'MarkerSize',8)


xlabel('Varitaion in CNDD, i.e., $\sigma_{\alpha_j}$','interpreter','latex');
ylabel('Lowest fitness difference (min\{$\tilde{\lambda}_j-\overline{\tilde{\lambda}_j}$\})','interpreter','latex');

title('(c) Variation in CNDD affects fitness-differences','interpreter','latex');

set(gca,'fontsize', 12);

axis([0 .15 -.025 .001])

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig2_fit.pdf'])




