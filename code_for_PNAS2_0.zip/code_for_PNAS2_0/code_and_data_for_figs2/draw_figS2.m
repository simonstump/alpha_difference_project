%This is for Figure S2.  It uses files ''20171108_same_ri_1', ''20171108_same_ri_2', '20171108_same_ri_3', and '20171108_same_ri_4'.

close all
clc, clear

load('20171108_same_ri_1.mat')

CNDD=reshape(SPP_MAT_ALL(:,4,1:ANUM),SPP,ANUM);
sig1=std(CNDD);
alpha1=alpha;
lam1=mean(r_i);
lfirst1=mean(log(firstLoss*death));
nspp1=mean(numSpp(:,1:20))*SPP;


load('20171108_same_ri_2.mat')

CNDD=reshape(SPP_MAT_ALL(:,4,1:ANUM),SPP,ANUM);
sig2=std(CNDD);
alpha2=alpha;
lam2=mean(r_i);
lfirst2=mean(log(firstLoss*death));
nspp2=mean(numSpp(:,1:20))*SPP;


load('20171108_same_ri_3.mat')

CNDD=reshape(SPP_MAT_ALL(:,4,1:ANUM),SPP,ANUM);
sig3=std(CNDD);
alpha3=alpha;
lam3=mean(r_i);
lfirst3=mean(log(firstLoss*death));
nspp3=mean(numSpp(:,1:20))*SPP;



load('20171108_same_ri_4.mat')

CNDD=reshape(SPP_MAT_ALL(:,4,1:ANUM),SPP,ANUM);
sig4=std(CNDD);
alpha4=alpha;
lam4=mean(r_i);
lfirst4=mean(log(firstLoss*death));
nspp4=mean(numSpp(:,1:20))*SPP;




%%%%%%%%%%%%%%%%%%%%
figA=figure();

plot(sig1,lfirst1,'ko-',...
    sig2,lfirst2,'ks-',...
    sig3,lfirst3,'k*-',...
    sig4,lfirst4,'k^-',...
    'LineWidth',2,'MarkerSize',8)

l=legend(['$\overline{\alpha_j}=$',num2str(alpha1)],...
    ['$\overline{\alpha_j}=$',num2str(alpha2)],...
    ['$\overline{\alpha_j}=$',num2str(alpha3)],...
    ['$\overline{\alpha_j}=$',num2str(alpha4)]);

set(l,'Interpreter','latex','Location','NorthEast');


xlabel('Variation in CNDD (or yield equivalent)','interpreter','latex');
ylabel('mean(log(time to 1st species lost))','interpreter','latex');


title('(a) How fast species are lost in each community','interpreter','latex');

%title('(c) Rank-abundance distribution in each commuinity','interpreter','latex');
set(gca,'fontsize', 12);

axis([0 max(sig1) 1.5 5])

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_sup1_time_to_first_loss.pdf'])



%%%%%%%%%%%%%%%%%%%%
figA=figure();

plot(sig1,nspp1,'ko-',...
    sig2,nspp2,'ks-',...
    sig3,nspp3,'k*-',...
    sig4,nspp4,'k^-',...
    'LineWidth',2,'MarkerSize',8)


xlabel('Variation in CNDD (or yield equivalent)','interpreter','latex');
ylabel('Mean richness after 2000 generations','interpreter','latex');


title('(b) Number of species maintained in each community','interpreter','latex');

set(gca,'fontsize', 12);
axis([0 max(sig1) 1 11])


set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_sup1_num_spp.pdf'])

