%This makes Figure 4.  It uses 'for_fig_N_and_r2'.

clear, clc, close all

load('for_fig_N_and_r2')

figA=figure();


plot(NVAL,NVAL*0+1,'k-',...
    NVAL,reshape(r1CNDDmean,25,10),'m-',...
    ...%n_alpha(i,:),n_alpha(i,:)*0+1,'mo',...
    'LineWidth',2,'MarkerSize',8)


xlabel('Abundance, $N_j$','interpreter','latex');
ylabel('Growth rate, $\tilde{\lambda}_j$','interpreter','latex');



title('(a) Abundance vs. growth, $\alpha_j$ varies','interpreter','latex');

set(gca,'fontsize', 12);
axis([.01 .25 .96 1.025])


set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_temp_n_and_rAALT.pdf'])


%%%%%%%%%%%%%%%%%%%%%



figA=figure();


plot(NVAL,NVAL*0+1,'k-',...
    NVAL,reshape(r1Ymean,25,10),'g-',...
    'LineWidth',2,'MarkerSize',8)

xlabel('Abundance, $N_j$','interpreter','latex');
ylabel('Growth rate, $\tilde{\lambda}_j$','interpreter','latex');


title('(b) Abundance vs. growth, $Y_j$ varies','interpreter','latex');

set(gca,'fontsize', 12);
axis([.01 .25 .96 1.025])


set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_temp_n_and_rBALT.pdf'])


