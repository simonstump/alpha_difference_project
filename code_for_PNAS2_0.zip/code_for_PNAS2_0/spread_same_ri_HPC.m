function out = spread_same_ri_HPC(theSeed,theName, disp, SPP,alpha)

% out = spread_same_ri_HPC(theSeed,theName, disp, SPP,alpha)
%
%This function is similar to spread_can_invade_long, but is used to generate and compare
%two types of communities: those where \alpha_j varies, and those where Y_j varies.  Thus, 
%the data can be used for something like Figure 3.  It also considers stochastic
%stability. I made it a function so that I can run it in parallel a bunch of times using 
%our HPC.  It saves the data as a function called "save(['20171108_same_ri_',theName])", 
%and the out is pretty meaningless.
%
%Basically, I construct a whole bunch of communities where \alpha_j varies (the difference 
%is in how much \alpha_j varies between species, essentially \sigma_\alpha).  I then use 
%the program dies_out_func2.m to determine the deterministic and stochastic stability.  I 
%then construct several equivalent communities where Y_j varies, but species have the same 
%invader growth rates.  I then run dies_out_func2.m on each of those communities.
%
%The output function has a couple of really critical pieces of data:
%SPP_MAT_ALL- This is a SPPx4xC matrix (where C is the number of communities considered), 
%  where the third dimension is different for every community.  The 4th column is the
%  alpha values, and the 1st column is the yield values.
%firstLoss- This is a CxREP matrix (for the C communities and REP replicates).  Each value 
%  tells you how many time steps passed before the first species was lost from the 
%  community in one replicate.  The mean of this is a useful measure of stochastic 
%  stability.
%numSpp- This is a CxREP matrix.  Each value is the number of species remaining at the end 
%  of a simulation in a small community.  The mean of this is a useful measure of 
%  stochastic stability.
%nbarVal- This is a CxSPP matrix (for C communities with SPP species).  It tells the 
%  density of a species in a given community.
%r_i- This is a SPPxC matrix.  Each column represents all of the invader growth 
%  rates for each member of a community, and each row is a particular member of the 
%  community.  This is thus a measure of deterministic stability.
%
%The program takes the following inputs:
%theSeed- This is the seed for the random number generator.
%theName- This is what I call the output .mat file.
%disp- The seed dispersal rate (d).
%SPP- The number of species.
%alpha- The mean of \alpha_j.

%%uncomment this if you are running this program as a subroutine.
%theSeed=1;
%theName='1'
%disp=.8
%SPP=5

out = nan;

%set the random seed
rng(theSeed)

%get the parameters

Y=1;  %this is the yield when all species have the same yield
death=.4;  %this is the death rate of each species



%GEN is a vector that has lots of information about each community.
% %GEN = [AREA, INVADE, INVADE_max, INVADE_min, PRETIME, TIME,...
% %      RECORD_TIME, invader#]


SMALLSIZE=200*SPP;
GEN = [SMALLSIZE, .002, .005, .001, 0, 5000, 1, 0];  %for stochastic stability
GEN2= [50000, .002, .005, .001, 0 2000, 1500, 0];  %for deterministic stability
GEN3= [50000, .002, .005, .001, 0 5000, 2500, 0];  %for equilibrium frequency

REPS=2000;  %number of simulations for stoch. stability
REP2=20;  %number of simulations for det. stability
REP3=8;  %number of simulations for equilibrium frequency
RUN4=250;


ADJUST_Y=1;

if(0)   %this is for testing only, 1 if a test run, 0 otherwise
   % SPP=5;
    SMALLSIZE=500;
    GEN = [SMALLSIZE, .002, .005, .001, 0, 500, 1, 0];
    GEN2= [2000, .002, .005, .001, 0 200, 150, 0];
    GEN3= [2000, .002, .005, .001, 0 50, 25, 0];

    REPS=100;
    REP2=1;
    REP3=4;
    RUN4=1;
end



if(0)   %this is for testing densities, 1 if a test run, 0 otherwise
    
    SMALLSIZE=500;
    GEN = [SMALLSIZE, .002, .005, .001, 0, 5, 1, 0];
    GEN2= [2000, .002, .005, .001, 0 20, 10, 0];
    GEN3= [50000, .002, .005, .001, 0 5000, 2500, 0];

    REPS=1;
    REP2=1;
    REP3=8;
end


if(0)  %this is for just the demographic stochasticity part
    'just stochasticity part'
    SMALLSIZE=2000;
    GEN = [SMALLSIZE, .002, .005, .001, 0, 5000, 1, 0];
    GEN2= [50000, .002, .005, .001, 0 2000, 1500, 0];
    GEN3= [50000, .002, .005, .001, 0 3000, 2500, 0];
    
    REPS=2000;
    REP2=0;
    REP3=8;
    RUN4=00;

end


%I use the next two lines to say that there is zero habitat partitioning.
thevar = 10^-10;
COV_MAT = thevar*eye(SPP);

%SPREAD is a vector, which determines how much \alpha_j will vary within a community (basically, how many mean(\alpha)'s there are between the highest and lowest individual).  Each value in the vector corresponds to a particular community.  If SPREAD(i)=0, then in community i, all species have the same \alpha_j.  If SPREAD(i)=1, then the weakest species has \alpha_j=1.5*mean(alpha) and the strongest has \alpha_j=0.5*mean(alpha)
SPREAD=[0:.1:1.9];

%ANUM is the number of communities that will be built where \alpha varies.  The total number of communities simulated will be double this.
ANUM=length(SPREAD);


numSpp=zeros(REPS,ANUM*2);  %stoch. stability: number of species who survive to the end of a simulation
r_i=zeros(SPP,ANUM*2);  %det. stability: the invader growth rates of each species
nbarVal=r_i;  %equilibrium density


%Here I set up SPP_MAT, the matrix of species values, for the community where \alpha_j differs
SPP_MAT=ones(SPP,4);  %yields
SPP_MAT(:,3)=death;   %death rate
SPP_MAT(:,2)=disp;    %dispersal rate
SPP_MAT_ALL=repmat(SPP_MAT,1,1,ANUM*2);  %SPP_MAT_ALL is a 3 dimensional-matrix. Basically, SPP_MAT_ALL(:,:,1) is community #1, SPP_MAT_ALL(:,:,2) is community #2, etc. The first ANUM are where \alpha_j varies, after that is where Y_j varies.


%Here I plug the values of \alpha_j in to the communities where \alpha_j varies.
for i=1:ANUM
    
    %i
    
    s=SPREAD(i);
    
    if(s==0)
        SPP_MAT_ALL(:,4,i)=alpha;
    else
        SPP_MAT_ALL(:,4,i)=alpha*[(1-s/2):s/(SPP-1):(1+s/2)];
    end
    
end
SPP_MAT_ALL

%First I calculate the equilibrium frequencies of each species
'calculate the ns'
ANUM
nbar=zeros(ANUM*2,SPP);
size(nbar)

'calculating n'

%parpool(feature('NumCores'));

%dies_out_func2 runs 3 routines; however, the two 0's mean I don't analyze stochastic or deterministic stability here.
parfor i=1:ANUM
    i

    %the x values are discarded, all I care about are the bar's.
    [x1 x2 x3 nbar(i,:)] = dies_out_func2(SPP_MAT_ALL(:,:,i), GEN, GEN2, GEN3, COV_MAT, ones(1,SPP)/SPP, 0, 0, REP3)
end

%I average across REP3 simulations. 
nbar(ANUM+1:2*ANUM,:)=nbar(1:ANUM,:)

%out=nbar
%return

%here I make sure that every species has a positive density
nbar=nbar*(1-SPP/100)+.01;

if(REP2==0)
    REP3=0;
end

'starting variation in alpha'

%here I run my simulations
parfor i=1:ANUM
    
    i
    
    [fl ns r n]=dies_out_func2(SPP_MAT_ALL(:,:,i), GEN, GEN2, GEN3, COV_MAT, nbar(i,:), REPS, REP2, REP3);
    
    firstLoss(:,i)=fl;
    numSpp(:,i)=ns;
    r_i(:,i)=mean(r,2);
    nbarVal(:,i)=n;
    
    
end

%I save it here, in case the simulation quits out.
save(['20171108_same_ri_',theName])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
'starting the variation in yields'

%first I figure out what Y_j values will make equivalent communities.

ribar=mean(r_i(:,1:ANUM))   %ribar is the mean invader growth rate
riChange=ribar(1:ANUM)./ribar(1)   %this is how much the mean invader growth rate differs from the 1st simulation.

%To calculate the Y_j's, I take advantage of the fact that their relative values matter more than their absolute values.  
for(i=1:ANUM)
    i

    %first I set the \alpha_j values for all species.  I assume here that trial #1 is the community where all species have the same \alpha.  I use this as a baseline, to make sure that the invader growth rates are the same.  Basically, if the invader growth rates in community k are 20% less than they communities when \alpha_j values are the same, then I reduce the \alpha_j to by 20%.
    SPP_MAT_ALL(:,4,i+ANUM)=alpha*riChange(i);
       
    %next, I set the relative values of Y_j, using the equation in SI Materials & Methods: Computer simulations
    forY=(r_i(:,i)-ribar(i))*(SPP-1)/SPP/((2*disp-disp^2))
    
    %Then I assign them.
    SPP_MAT_ALL(:,1,i+ANUM)=exp(forY);
    
    SPP_MAT_ALL(:,:,i+ANUM)
    %pause
    
end

'starting parfor for yields'


%here I run my simulations
parfor i=ANUM+1:2*ANUM
    
    i
    
    [fl ns r n]=dies_out_func2(SPP_MAT_ALL(:,:,i), GEN, GEN2, GEN3,...
        COV_MAT, nbar(i,:), REPS, REP2, REP3);
    
    i
    %fl
    %ns
    %r
    %n
    %size(fl)
    firstLoss(:,i)=fl;
    numSpp(:,i)=ns;
    r_i(:,i)=mean(r,2);
    nbarVal(:,i)=n;
    
end

'Opuwo!!!'

save(['20171108_same_ri_',theName])