function out = mycov(x,y)

%This gives the non-normalized covariance between X and Y.  I wrote this because I was tired of needing 2 lines of code to calculate the covariance.

mat=cov(x,y,1);
out=mat(1,2);