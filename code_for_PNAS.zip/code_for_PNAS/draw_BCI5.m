 %This makes Figure 5, and crunches the data for how much variation in CNDD reduces stability.

clc, clear, close all

%Here I load the data from Comita et al. (2010) and (2007) into a matrix called Ldata.
liza_data

%Here are the dispersal (d) values I consider.
disp=[.3:.001:.99];
theDif=0.003;

%CONS, CONBA, N_dbh, N_number

SPP=size(Ldata,1)   %Number of species

%Here are two measures of frequency (N_j)
guessN1=Ldata(:,3)/sum(Ldata(:,3));  %frequency as DBH
guessN2=Ldata(:,4);   %frequency as number of reproductive adults.

CNDD_A=-Ldata(:,2);   %the effect of CNDD
%CNDD_S=-Ldata(:,1);

%%%%%%%%%%%%%
%First I calculate the relevant variables for when N_j is determined by DBH

%Loss is the covariance between N_j and \alpha_j (i.e. how much the stabilizing effect is reduced by variation)
loss=mycov(guessN1/(sum(guessN1)),CNDD_A)

%abar is the stabilizing effect if all species had the same CNDD and d=1.
abar=mean(CNDD_A)/(SPP-1)

%Diff is the amount that the stabilizing effect is reduced by variation in CNDD.
diff=(abar+loss)

%This is Eq. (5) in the main text: the amount that variation in CNDD reduced its stabilizing effect.
diffFrac=diff/abar

%DeltaP is the estimated stabilizing effect of CNDD.
DeltaP=disp.^2*diff;

%fitDiff is the estimated fitness differences produced by CNDD.
fitDiff=(mean(CNDD_A)-CNDD_A)*...
    ((disp.*(1-disp))*SPP/(SPP-1)+disp.^2/(SPP-1)^2);

%r_i is the combination of stabilizing effects and fitness differences.
r_i=fitDiff+repmat(DeltaP,SPP,1);

%survives is the number of species who we suspect will persist, given the stabilizing mechanism and fitness differences.
survives=sum(r_i>0);


%%%%%%%%%%%%%
%Second I calculate the relevant variables for when N_j is determined by adult abundance

lossS=mycov(guessN2/(sum(guessN2)),CNDD_A)
abarS=mean(CNDD_A)/(SPP-1)
diffS=(abarS+lossS)

diffFracS=diffS/abarS

DeltaPS=disp.^2*diffS;

fitDiffS=(mean(CNDD_A)-CNDD_A)*...
    ((disp.*(1-disp))*SPP/(SPP-1)+disp.^2/(SPP-1)^2);

r_iS=fitDiffS+repmat(DeltaPS,SPP,1);

survivesS=sum(r_iS>0);

%%%%%%%%%%
%Below I calculate the mean CNDD and the weighted mean, for fig. 5a

meanA=mean(CNDD_A);
weightMean1=sum(CNDD_A.*guessN1);  %weighted by DBH
weightMean2=sum(CNDD_A.*guessN2);  %weighted by adults

yval=[.12 0];  %This is how tall the line is that points to the mean.


%%%%%%%%%%%%
%Here make figure 5a.

figA=figure();


plot(CNDD_A,guessN1,'ro',CNDD_A,guessN2,'k^','LineWidth',3)
hold on
plot(meanA*[1 1],yval,'k--',...
    weightMean1*[1 1],yval,'r-',...
    weightMean2*[1 1],yval,'k-','LineWidth',3)
hold off

l=legend('Basal area','$\#$ of adults');
set(l,'Interpreter','latex','Location','NorthEast');


xlabel('Effect of CNDD, $\alpha_j$','interpreter','latex','FontSize',14,...
    'fontname','timesnewroman');
ylabel('Frequency, $N_j$','interpreter','latex','FontSize',14,...
    'fontname','timesnewroman');

title('(a) Data from Comita et al. (2010)','interpreter','latex',...
    'FontSize',14,'fontname','timesnewroman');

set(gca,'fontsize', 12);

set(gca,'fontname','timesnewroman')

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig4_comita_figA.pdf'])


%%%%%%%%%%
%Here I make Fig. 5b

figB=figure();

plot(disp,survives,'r-',...
    disp,survivesS,'k-','LineWidth',3,'MarkerSize',12)



axis([.5 1 0 SPP])

%myarrow(.65, SPP, .65, 10,'LineWidth',3)


xlabel('Dispersal fraction, $d$','interpreter','latex');
ylabel('Number of species with $\Delta P_j>0$','interpreter','latex');

title('(b) Number of spp. maintained by CNDD','interpreter','latex');

set(gca,'fontsize', 12);
set(gca,'fontname','timesnewroman')



set(figB,'Units','Inches');
pos = get(figB,'Position');
set(figB,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figB,'fig4comitafigB.pdf')


