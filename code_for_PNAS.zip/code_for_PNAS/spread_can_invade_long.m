function out = spread_can_invade_long(theSeed,theName, disp, SPP, alpha)

% out = spread_can_invade_long(theSeed,theName, disp, SPP,alpha)
%
%This function is generates communities and sees how stable they are (deterministic only).  %This code is used to generate the data for Fig. 2 and S1. It saves them to a file called
%save(['20171113_alphaSpread4_',theName]).  The out only tells you how long it took to run 
%the simulation.  
%
%Basically, I construct a whole bunch of communities where \alpha_j varies (the difference 
%is in how much \alpha_j varies between species, essentially \sigma_\alpha).  I then use 
%the program one_invasion.m to determine the deterministic and stochastic stability.  
%
%The output function has a couple of really critical pieces of data:
%r_i- This is a SPPxreplicates matrix.  Each column represents all of the invader growth 
%rates for each member of a community, and each row is a particular member of the 
%community.
%ritemp is similar, but it has a third dimension which is the invader growth rate on every individual simulation (these are averaged to give r_i).
%SPP_MAT_ALL- This is a SPPx4xreplicates community, where the third dimension is different 
%for every community.  The 4th column is the alpha values, and the 1st column is the yield values.
%
%The program takes the following inputs:
%theSeed- This is the seed for the random number generator.
%theName- This is what I call the output .mat file.
%disp- The seed dispersal rate (d).
%SPP- The number of species.
%alpha- The mean of \alpha_j.


out = nan;

rng(theSeed)

%set the parameters

Y=1;   %this is the average yield value
death=.4;  %this is the death rate of all species


%GEN is a vector that has lots of information about each community.
%A summary is below, but it is detailed in JC_different_alphas.m
% %GEN = [AREA, INVADE, INVADE_max, INVADE_min, PRETIME, TIME,...
% %      RECORD_TIME, invader#]
GEN= [100000, .002, .005, .001, 0 2500, 1500, 0];

REPS=30;  %REPS is the number of repeated runs

%%uncomment this to make the code run faster, for testing only
%GEN= [5000, .02, .025, .01, 0 200, 150, 0];
%REPS=3;


if(0)   %this is for testing only, 1 if a test run, 0 otherwise
    SPP=5;
    GEN= [1000, .02, .05, .01, 0 800, 100, 0];
    
    REPS=2;
    
end




%%%%%%

thevar = 10^-10;    %do not change this, legacy code
COV_MAT = thevar*eye(SPP);   %do not change this, legacy code

%SPREAD is a vector, which determines how much \alpha_j will vary within a community 
%(basically, how many mean(\alpha)'s there are between the highest and lowest individual).  
%Each value in the vector corresponds to a particular community.  If SPREAD(i)=0, then in 
%community i, all species have the same \alpha_j.  If SPREAD(i)=1, then the weakest 
%species has \alpha_j=1.5*mean(alpha) and the strongest has \alpha_j=0.5*mean(alpha)
SPREAD=[0:.1:1.9];

%ANUM is the number of communities that will be built where \alpha varies.  The total 
%number of communities simulated will be double this.
ANUM=length(SPREAD);


numSpp=zeros(REPS,ANUM);   %stochastic stability: number of species who survive to the end of the simulation.
r_i=zeros(SPP,ANUM);   %deterministic stability: invader growth rates of each species


%Here I set up SPP_MAT, the matrix of species values.  The 3rd dimension will differ between simulations.
SPP_MAT=ones(SPP,4);   %create the matrix, and set yields to 1
SPP_MAT(:,3)=death;    %death rate
SPP_MAT(:,2)=disp;     %dispersal rate
SPP_MAT_ALL=repmat(SPP_MAT,1,1,ANUM);   %SPP_MAT_ALL is a 3 dimensional-matrix. Basically, SPP_MAT_ALL(:,:,1) is community #1, SPP_MAT_ALL(:,:,2) is community #2, etc. The first ANUM are where \alpha_j varies, after that is where Y_j varies.



%Here I set the alpha_j values for each community
for i=1:ANUM
     s=SPREAD(i);
    
    if(s==0)
        SPP_MAT_ALL(:,4,i)=alpha;
    else
        SPP_MAT_ALL(:,4,i)=alpha*[(1-s/2):s/(SPP-1):(1+s/2)];
    end
    
end




'starting parfor'

%REPS2=REPS

%these are just for measuring the passage of time, to see how long the simulation takes.
timeNow1=zeros(ANUM,6)
timeNow2=timeNow1;

RUNNUM=REPS*ANUM  %this is the number of runs needed for the invader growth rates.

AllRUNS=zeros(SPP,RUNNUM)  %here we record the invader growth rates for all runs.  they are saved in a confusing order, but averaged over later.

parpool(feature('NumCores'));

%here I run my simulations
parfor(i=1:RUNNUM, 12);
    %'start'
    ['start ',num2str(i)]
    timeNow1(i,:)=clock;
    
    ALLRUNS(:,i)=one_invasion(SPP_MAT_ALL(:,:,mymod(i,ANUM)), GEN, COV_MAT);
        
    timeNow2(i,:)=clock;
    %'end'
    %i
    ['end ',num2str(i)]
    
end

save(['20171113_alphaSpread4_',theName])

%Here I rearrange the invader growth rates to r_i, so they are easier to use later.
%when it is like this, each column represents one community, and each row is an 
%individual species.  The third dimension, which I average over later, is each replicate.

ritemp=zeros(SPP,ANUM,REPS)

for i=1:RUNNUM
    ritemp(:,mymod(i,ANUM),floor((i-1)/ANUM)+1)=ALLRUNS(:,i);
    
end

r_i=mean(ritemp,3)

save(['20171113_alphaSpread4_',theName])

out=[timeNow1(:,4:6), timeNow2(:,4:6)]

