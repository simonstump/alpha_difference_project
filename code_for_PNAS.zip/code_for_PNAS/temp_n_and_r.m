%temp_n_and_r.m is used to determine the relationship between abundance and finite rate of increase (i.e., \tilde{\lambda_j}.  i.e., this generates the data for Fig. 4.
%
%You will give it two communities, below called SPP_MAT and SPP_MAT2.  You will need to make sure that they are equivalent.  Right now they are set for the data for Fig. 4, though you can set them up however you like.  Right now it is set up so that both communities need to have the same number of species.  It only compares 2 communities, but it shouldn't be hard to make it more than 2 if you want.  
%
%The program runs by taking advantage of a feature of the JC_different_alphas.m program.  Basically, when you make a species an "invader", you can set up what densities you want that species to have.  I originally designed this so that the "invader" would have a density of nearly 0; however, the program works just fine if you want the invader's density to be 0.25.  The program thus holds each species' density at various levels, and calculates \tilde{\lambda} for that species.  It does it for each species in both communities.

close all

clc, clear

%This is the community where \alpha_j varies between species.
%As a reminder, the first column is Y_j, the second column is d, the third column is \delta, and the fourth column is \alpha_j.
SPP_MAT=[    1.0000    0.9000    0.4000    0.2400
    1.0000    0.9000    0.4000    0.2756
    1.0000    0.9000    0.4000    0.3111
    1.0000    0.9000    0.4000    0.3467
    1.0000    0.9000    0.4000    0.3822
    1.0000    0.9000    0.4000    0.4178
    1.0000    0.9000    0.4000    0.4533
    1.0000    0.9000    0.4000    0.4889
    1.0000    0.9000    0.4000    0.5244
    1.0000    0.9000    0.4000    0.5600];

%This is an equivalent community where Y_j varies between species.
SPP_MAT2=[    1.0197    0.9000    0.4000    0.3422
    1.0147    0.9000    0.4000    0.3422
    1.0097    0.9000    0.4000    0.3422
    1.0057    0.9000    0.4000    0.3422
    1.0006    0.9000    0.4000    0.3422
    0.9972    0.9000    0.4000    0.3422
    0.9937    0.9000    0.4000    0.3422
    0.9896    0.9000    0.4000    0.3422
    0.9864    0.9000    0.4000    0.3422
    0.9835    0.9000    0.4000    0.3422];

%SPP is the number of species in the community.  IT must be the same between communities.
SPP=length(SPP_MAT);

%This is legacy.  If you want habitat partitioning to occur, then COV_MAT is the covariance matrix of the environmental response (see Stump 2017 AmNat).  Otherwise, just leave it as is.
COV_MAT=eye(SPP)*10^-10;


%GEN gives general data about the community.  Don't anything other than the 1st number (which is the size of the community), the 6th number (the length of the simulation), the 7th number (the number of time steps that you use to calculate growth rates; essentially, #6-#7 is the amount of time given to let the community equilibrate).  
GEN=[100000 0 0 0 0 2000 1000 0];

%NVAL gives the density values you will consider for each species (i.e. the N_j's).  
NVAL=[.01:.01:.25];

%REPS determines how many simulations you run per parameter set.  I found that 16 gives pretty consistent results.  
REPS=16;


r1CNDD=zeros(REPS,length(NVAL),SPP);
r1Y=r1CNDD;
r2CNDD=r1CNDD;
r2Y=r1CNDD;


for i=1:REPS;  %for each replicate
parfor j=1:length(NVAL)  %for every density
    for k=1:SPP  %for every species
    j/length(NVAL)
    
    %I run the "invasion analysis" here.  I alter GEN so that species k is the "invader", and hold the density at NVAL(j) plus or minus 0.005.
    r1CNDD(i,j,k)=JC_different_alphas(SPP_MAT, COV_MAT, ...
        GEN+[0 NVAL(j) NVAL(j)+.005 NVAL(j)-.005 0 0 0 k]);
    r1Y(i,j,k)=JC_different_alphas(SPP_MAT2, COV_MAT, ...
        GEN+[0 NVAL(j) NVAL(j)+.005 NVAL(j)-.005 0 0 0 k]);
    end
end
end

r1CNDDmean=mean(r1CNDD)
r2CNDDmean=mean(r2CNDD)

save('for_fig_N_and_r2')
