%This file makes the Figures S4.  You will first need to run 
%temp_test_cov_approx.m, and get an information file called 
%data_for_cov_approx.mat.

clear, clc, close all

load('data_for_cov_approx')

RUNS=i;  %if you didn't finish the simulation, this goes until you are done.

%I eliminate any communities with 2 or fewer species.  So, these keep 
%track of that.  Some of my data is recorded as 1 data point per species, 
%this is recorded in theNum.  Other data is recorded as 1 data point per 
%community, this is recorded with theSmallNum.
theNum=1;
theSmallNum=1;


for i=1:RUNS
    SPP=saveSPP(i);  %the number of species in the community.
    
    
    if(SPP>2)
        alpha=saveA(1:SPP,i);
        death=SPP_MAT(1,2);
        nbarAll=saveN(1:SPP,i);
        meanN=saveNi(1:SPP,1:SPP,i);
        lami=saveRi(1:SPP,i);
        ri=(lami-1)/death;
        lami2=saveRi2(1:SPP,i);
        ri2=(lami2-1)/death;
        
        oldRiGuess=saveRiguess(1:SPP,i);  %my estimate of normalized invader growth rate
        
        thecov=0;
        
        covAll=mycov(alpha,nbarAll);  %the covariance between alpha and N in the full community.
        
        abar=mean(alpha);  %the mean value of alpha in the community.
        
        %here I calculate the covariance between alpha and N in each community when one species is an invader.  I save it as theca
        for j=1:SPP
            alpha_temp=alpha;
            alpha_temp(j)=[];
            
            nbar_temp=meanN(j,:)';
            nbar_temp(j)=[];
            nbar_temp=nbar_temp/sum(nbar_temp)
            
            thecov(j)=mycov(alpha_temp,nbar_temp)
            
        end
        
        %here I record the actual average covariance and my estimate.
        actualMeanCov(theSmallNum)=mean(thecov(1:SPP))
        firstMeanGuess(theSmallNum)=covAll

        
        
        %%%%%%%%%%%%%%
        
        %here I record the growth rates of each individual        
        actualRi(theNum:theNum+SPP-1)=ri;
        actualRi2(theNum:theNum+SPP-1)=ri2;

        %here I record the estimated growth rate of each individual.
        oldGuess(theNum:theNum+SPP-1)=oldRiGuess;
        
        %I record the mean stabilizing mechanism, and my estimate.
        actualStab(theSmallNum)=mean(ri);
        oldStabGuess(theSmallNum)=saveStabguess(i);
        
        %I update theNum and theSmallNum
        theNum=theNum+SPP;
        theSmallNum=theSmallNum+1;
        
    end
    
end



figA=figure();


all=[actualMeanCov,firstMeanGuess]
m=[min(all), max(all)]
plot(m, m,'k--',...
    actualMeanCov,firstMeanGuess,'r.',...
    'LineWidth',3,'MarkerSize',12)


xlabel('Actual covariance, $\overline{\mbox{cov}(N_j^{\{-i\}},\alpha_j)}^{-i}$','interpreter','latex');
ylabel('Predicted covariance, cov$(N_j,\alpha_j)$','interpreter','latex');


title('(a) Covariance approximation',...
    'interpreter','latex');

set(gca,'fontsize', 12);

axis([m(1) m(2) m(1) m(2)])

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_many_covAN_approx3a.pdf'])


figA=figure();
all=[actualRi,oldGuess];
m=[min(all), max(all)]
plot(m, m,'k--',...
    actualRi,oldGuess,'r.',...
    'LineWidth',3,'MarkerSize',12)

xlabel('Actual growth rate, $\overline{\tilde{\lambda}_i}$','interpreter','latex');
ylabel('Predicted growth rate, $\Delta P_j + \Delta Y_j$','interpreter','latex');


title('(b) Invader rowth rate approximation',...
    'interpreter','latex');

set(gca,'fontsize', 12);
axis([m(1) m(2) m(1) m(2)])

set(figA,'Units','Inches');



pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_many_covAN_approx3b.pdf'])



figA=figure();
all=[actualStab,oldStabGuess];
m=[min(all), max(all)]
plot(m, m,'k--',...
    actualStab,oldStabGuess,'r.',...
    'LineWidth',3,'MarkerSize',12)


%l=legend('line','guess1','guess2','guess3','guess4','guess5')%,...
%    %'Ignoring cov effects');
%set(l,'Interpreter','latex','Location','SouthEast');

xlabel('Actual stabilizing mechanism, $\tilde{\lambda}_i$','interpreter','latex');
ylabel('Predicted stabilizing mechanism, $\overline{\Delta P}$','interpreter','latex');


title('(c) Growth rate approximation',...
    'interpreter','latex');

set(gca,'fontsize', 12);
axis([m(1) m(2) m(1) m(2)])

set(figA,'Units','Inches');


pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_many_covAN_approx3c.pdf'])



corr(actualRi',actualRi2')
%corr(actualRi',guess1')

corr(actualRi',oldGuess')
%corr(guess1',oldGuess')

corr(actualStab',oldStabGuess')