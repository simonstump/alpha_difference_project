%This is for Figure S3.  It uses data from 20171026_alpha_var_2spp_3.mat

close all
clc, clear, load('20171026_alpha_var_2spp_3')



CNDD=reshape(SPP_MAT_ALL(:,4,1:ANUM),SPP,ANUM);


sig=reshape(mean(SPP_MAT_ALL(:,4,1:12)),[1 12]);

lam=mean(r_i);

NUM_TRIALS=length(lam);
lfirst=mean(log(firstLoss*death));


nspp=mean(numSpp)*SPP;


%%%%%%%%%%%

    nspp_corLam=nspp;
    lfirst_corLam=lfirst;
    nspp_corAlph=nspp;
    lfirst_corAlph=lfirst;

%%%%%%%


figA=figure();

r_i=(r_i*death+1)
lam=lam*death+1

plot(sig,r_i(1,1:ANUM),'mo-',...
    sig,r_i(1,ANUM+1:2*ANUM),'go-',...
    sig,r_i(2,1:ANUM),'m^-',...
    sig,r_i(2,ANUM+1:2*ANUM),'g^-',...
    sig,lam(1:ANUM),'m--',...
    sig,lam(ANUM+1:2*ANUM),'g--',...
    'LineWidth',3,'MarkerSize',12)

l=legend('different CNDD, low $\alpha_j$','different yield, high $Y_j$',...
    'different CNDD, high $\alpha_j$','different yield, low $Y_j$',...
    'mean, variable $\alpha_j$', 'mean, variable $Y_j$');
set(l,'Interpreter','latex','Location','NorthWest');

xlabel('Mean CNDD, $\overline{\alpha}$','interpreter','latex');
ylabel('Invader growth rate','interpreter','latex');

axis([min(sig) max(sig) 1 1.4])


title('(a) Deterministic stability','interpreter','latex');

set(gca,'fontsize', 12);


set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_2spp_r_i.pdf'])



%%%%%%%%%%%%%%%%%%%%
figA=figure();



plot(sig,sig./sig*log(GEN(6)*death),'k--',...
    sig,lfirst(1:ANUM),'mo-',...
    sig,lfirst(ANUM+1:2*ANUM),'go-',...
    'LineWidth',3,'MarkerSize',12)


xlabel('Mean CNDD, $\overline{\alpha}$','interpreter','latex');
ylabel('mean(log(time to 1st species lost))','interpreter','latex');


title('(b) How fast species are lost in each community','interpreter','latex');

set(gca,'fontsize',12);

axis([min(sig) max(sig) 5 8])


set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_2spp_time_to_first_loss.pdf'])



%%%%%%%%%%%%%%%%%%%%
figA=figure();

plot(sig,nspp(1:ANUM),'mo-',...
    sig,nspp(ANUM+1:2*ANUM),'go-',...
    'LineWidth',3,'MarkerSize',12)


xlabel('Mean CNDD, $\overline{\alpha}$','interpreter','latex');
ylabel('Mean richness after 2000 generations','interpreter','latex');


title('(c) Number of species maintained in each community','interpreter','latex');

set(gca,'fontsize',12);
axis([min(sig) max(sig) 1 2])



set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig_2spp_num_spp.pdf'])


