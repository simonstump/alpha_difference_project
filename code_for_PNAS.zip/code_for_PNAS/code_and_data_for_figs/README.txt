This folder contains all of the Matlab code needed to make the figures.  Each file is called "draw_figX.m", where the X corresponds to the figure in the paper.  There is no "draw_fig1" because that was made in powerpoint.

There are a few .m files that are needed to make those functions run, which have different names.

Any of the .mat files are code from a particular simulation, which are needed for the figures.

Finally, "combined_data.xlsx" contains the data that was merged from Comita et al. (2007) and Comita et al. (2010).  It was put in a usable form in liza_data.m.