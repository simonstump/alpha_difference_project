%This is for Figure 3.  It uses data from 20171108_same_ri_sec_x2

close all
clc, clear, load('20171108_same_ri_sec_x2')



CNDD=reshape(SPP_MAT_ALL(:,4,1:ANUM),SPP,ANUM);
sig=std(CNDD);


lam=mean(r_i);

NUM_TRIALS=length(lam);
lfirst=mean(log(firstLoss*death));

nspp=mean(numSpp)*SPP;



    nspp_corLam=nspp;
    lfirst_corLam=lfirst;
    nspp_corAlph=nspp;
    lfirst_corAlph=lfirst;



%%%%%%%%%%%%%%%%%%%%
figA=figure();

plot(sig,lfirst(1:ANUM),'m^-',...
    sig,lfirst(ANUM+1:2*ANUM),'go-',...
    'LineWidth',3,'MarkerSize',12)


l=legend('different CNDD, $\alpha_j$','different yield, $Y_j$');
set(l,'Interpreter','latex','Location','SouthWest');

xlabel('Variation in CNDD (or yield equivalent)','interpreter','latex');
ylabel('mean(log(time to 1st species lost))','interpreter','latex');


title('(a) How fast species are lost in each community','interpreter','latex');

set(gca,'fontsize', 12);

axis([0 max(sig) 3.5 6.9])

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig3_time_to_first_loss.pdf'])



%%%%%%%%%%%%%%%%%%%%
figA=figure();

plot(sig,nspp(1:ANUM),'m^-',...
    sig,nspp(ANUM+1:2*ANUM),'go-',...
    'LineWidth',3,'MarkerSize',12)

xlabel('Variation in CNDD (or yield equivalent)','interpreter','latex');
ylabel('Mean richness after 2000 generations','interpreter','latex');



title('(b) Number of species maintained in each community','interpreter','latex');

set(gca,'fontsize', 12);
axis([0 max(sig) 5.3 9.2])


set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig3_num_spp.pdf'])



%%%%%%%%%%%%%%%%%%%%%


shannon=sum(-log(nbarVal).*nbarVal,1)/log(10);
figA=figure();

plot(sig,shannon(1:ANUM),'m^-',...
    sig,shannon(ANUM+1:2*ANUM),'go-',...
    'LineWidth',3,'MarkerSize',12)


xlabel('Variation in CNDD (or yield equivalent)','interpreter','latex');
ylabel('Pielou evenness index, $H^\prime/H^prime_max$','interpreter','latex');

title('(c) Community evenness','interpreter','latex');

set(gca,'fontsize', 12);
axis([0 max(sig) 2.06 2.32])


set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['fig3_evenness.pdf'])
